# reading_license_plate > 2025-06-30 4:44pm
https://universe.roboflow.com/number-plate-detector-ya6ia/reading_license_plate

Provided by a Roboflow user
License: CC BY 4.0

